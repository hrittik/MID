<!doctype html>
<html>
<head>
<style>
table, th, td {
    border: 0px solid black;
    border-collapse: collapse;
	
}
p { 
    display: block;
    font-size: 1em;
    margin-top: 0.0em;
    margin-bottom: 0.0em;
    margin-left: 0;
    margin-right: 0;
    
}



</style>
</head>
	<body>
	
		<?php
        session_start();
       
		$h=fopen("test","w");
        $data="asdf asdf";
        fwrite($h,"Name of Applicant          ".$_SESSION['a'][0]."\n"."\n");
		fwrite($h,"First Part (name)          ".$_SESSION['a'][1]."\n"."\n");
		fwrite($h,"Second Part (surname)      ".$_SESSION['a'][2]."\n"."\n");
		fwrite($h,"Gender                     ".$_SESSION['a'][3]."\n"."\n");
		fwrite($h,"Email                      ".$_SESSION['a'][4]."\n"."\n");
		fwrite($h,"Date of Birth              ".$_SESSION['a'][5]."\n"."\n");
		fwrite($h,"Father Name                ".$_SESSION['a'][6]."\n"."\n");
		fwrite($h,"Mother Name                ".$_SESSION['a'][7]."\n"."\n");
		fwrite($h,"Spoue Name                 ".$_SESSION['a'][8]."\n"."\n");
		
		
        




        ?>
	
	
	
	
	
		
			<form method="Post" action="stage4.php">
				
				<table width="100%">
					<!-- 1st row -->
					<tr>
						<td width="1%"></td>
						<td>	
							<p style="color:black;font-weight: bold;">Passport Application-Review Enrolment Summery</p></br>
							
							
						
						
						</td>
						
					</tr>
					
					<!-- 2nd row -->
					<tr>
						<td width="1%"></td>
						<td><p style="color:Green;font-size: 0.7em; margin-bottom: 0.5em;font-weight: bold;"> &nbsp Online application id:000001213</p>
							<p style="color:Red;font-size: 0.7em;margin-top: 0.2em; margin-bottom: 1.5em;">&nbsp Remainder Before Submiting Your Application</p>
						</td>
						
							
					</tr>
					
					<!-- 3rd row  -->
					<tr>
						<td></td>
						
						<td >
							<TABLE width="100%">
							<!-- inner table row 1  -->
									<tr>
										<tr>
										<td width="1%"></td>
										<td colspan=2 ; width="40%">
										<p style="color:Green;font-size: 1em;margin-top: 0.2em; margin-bottom: 1.5em;">&nbsp Personal Information Summry</p><br>
											<p style="color:Black;font-size: 1em;font-weight: bold;">	
											<?php
											
											$data=file_get_contents("Test");
											echo "<pre>";
											print_r($data);
											
											?>
												
											</p></br>
										</td>
										<td width="5%"></td>
										
										<td colspan=2 ; width="50%">
											
										</td>
										
											
									</tr>
									
									
									
									
									
									
									
									
									
									
									<!-- inner table row 16  -->
									
									
									
									<td width="2%"></td>
										<td>	
												
												
												
										</td>
										
										<td>
										
											
											
											
										
										
										</td>
										<td width="10%"></td>
										
											
										<td height="30">	
											

											<a href="stage3.php" >
											<button type="button">Previous Page</button>	
											</a>
												
												
										</td>
										
										<td>
										
											
											
											<input type="Submit" name="submitOfStage3"  value="Save & Next">
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									
									
									
									
										
										
									
									
									
							        
									
									
							</TABLE>
							
							
						</td>
						
					</tr>
					
				</table>
				

			</form>
	</body>
</html>