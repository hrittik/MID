<!doctype html>
<html>
<head>
<style>
table, th, td {
    border: 0px solid black;
    border-collapse: collapse;
	
}
p { 
    display: block;
    font-size: 1em;
    margin-top: 0.0em;
    margin-bottom: 0.0em;
    margin-left: 0;
    margin-right: 0;
    
}

<?php
	
	session_start();
	

	
	if(!isset($_POST['stageTwo'])){
	$_SESSION['a'] = array();
	$_SESSION['a'][] = $_POST['nameOfApplicant'];//0
	$_SESSION['a'][] =$_POST['nameOfApplicantFirstPart'];//1
	$_SESSION['a'][] = $_POST['nameOfApplicantSecondPart'];//2
	$_SESSION['a'][] = $_POST['gender'];//3
	$_SESSION['a'][] = $_POST['applicantEmail'];//4
	$_SESSION['a'][] = $_POST['bday'];//5
	$_SESSION['a'][] = $_POST['nameOfFather'];//6
	
	$_SESSION['a'][] = $_POST['nameOfMother'];//7
	$_SESSION['a'][] = $_POST['nameOfSpoue'];//8
	
	
}
	?>



</style>
</head>
	<body>
		
			<form method="Post" action="stage3.php">
				
				<table width="100%">
					<!-- 1st row -->
					<tr>
						<td width="1%"></td>
						<td>	
							<p style="color:black;font-weight: bold;">Passport Application Stage-2</p></br>
							
							
						
						
						</td>
						
					</tr>
					
					<!-- 2nd row -->
					<tr>
						<td width="1%"></td>
						<td><p style="color:Green;font-size: 0.7em; margin-bottom: 0.5em;font-weight: bold;"> &nbsp Online application id:000001213</p>
							<p style="color:black;font-size: 0.7em;margin-top: 0.2em; margin-bottom: 1.5em;">&nbsp Fields marked with (<span style="color: red;">*</span>)madatory</p>
						</td>
						
							
					</tr>
					
					<!-- 3rd row  -->
					<tr>
						<td></td>
						
						<td >
							<TABLE width="100%">
							<!-- inner table row 1  -->
									<tr>
										<tr>
										<td width="1%"></td>
										<td colspan=2 ; width="40%">
											<p style="color:green;font-size: 0.8em;font-weight: bold;">Applicant Contact Information</p></br>
										</td>
										<td width="8%"></td>
										
										<td colspan=2 ; width="50%">
											<p style="color:green;font-size: 0.8em;font-weight: bold;">Old Passport Information</p></br>
										</td>
										
											
									</tr>
									
									<!-- inner table row 2  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Office No : <span style="color: red;">&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="text" name="OfficeNo" >
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td width="15%">
											<p style="color:black;font-size: 0.8em;">Passport No :<span style="color: red;">&nbsp</span></p>

										</td>
											
											
										
										
										<td>
											<input type="text" name="passportNo" >
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 3  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Residence No :<span style="color: red;">&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="text" name="ResidenceNo" >
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td width="15%">
											<p style="color:black;font-size: 0.8em;">Place of Issue : <span style="color: red;">&nbsp</span></p>

										</td>
											
											
										
										
										<td>
											<input type="text" name="placeOfIssue" >
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									
									<!-- inner table row 3  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Mobile No : <span style="color: red;">&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="text" name="mobileNo" >
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td width="15%">
											<p style="color:black;font-size: 0.8em;">Date Of Issue : <span style="color: red;">&nbsp</span></p>

										</td>
											
											
										
										
										<td>
											<input type="text" name="dateOfIssue" >
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 4  -->
									<tr>
										<tr>
										<td width="1%"></td>
										<td colspan=2 ; width="40%">
											<p style="color:green;font-size: 0.8em;font-weight: bold;">Emergency  Contact Person's Details</p></br>
										</td>
										<td width="8%"></td>
										
										<td>
											<p style="color:black;font-size: 0.8em;">Re Issue Reason : <span style="color: red;">&nbsp</span></p>
										</td>
										<td>
											<select  name="reIssueReason" >
												
												<option value="issue1"  selected >-Select-</option>
												<option value="other">Other</option>
												
												
											</select>
										</td>
										
											
									</tr>
									
									<!-- inner table row 5  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Name : <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="text" name="namePerson" required >
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td width="15%" >
											

										</td>
											
											
										
										
										<td>
											
											
											
										</td>
										
										
									
									
									
							        </tr>
									<!-- inner table row 6  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Country : <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<select  name="countryPerson" required >
												
												<option value="bangladesh"  selected >Bangladesh</option>
												<option value="">None</option>
												
												
											</select>
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td width="15%" >
											

										</td>
											
											
										
										
										<td>
											
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 7  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<input type="checkbox" name="Permanent_Address" value="Per_Add"> <i> Same as Permanent Address</i>
												
												
										</td>
										
										<td>
										
											
											
											
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>
											

										</td>
											
											
										
										
										<td>
											
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 8  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<input type="checkbox" name="Present_Address" value="Present_Add"><i>  Same as present Address</i>
												
												
										</td>
										
										<td>
										
											
											
											
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td width="15%" >
											

										</td>
											
											
										
										
										<td>
											
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 9  -->
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Village/House: <span style="color: red;">&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="text" name="villageHousepersentStage2" >
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td width="15%">
											

										</td>
											
											
										
										
										<td>
											
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 10  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Road/Block/Section : <span style="color: red;">&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="Text" name="roadPresentStage2" >
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>	
												
												
												
												
										</td>
										
										<td>
										
											
											
											
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									
									
									<!-- inner table row 11  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">District :<span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<select name="districPresentStage2" required>
												
												<option value="">-select-</option>
												<option value="distric">-district-</option>
												
												
											</select>
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>	
												
												
												
												
										</td>
										
										<td>
										
											
											
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 12  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Police Station: <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<select name="policePresentStage2" required>
												
												<option value=""  >-select-</option>
												<option value="police">police</option>
												
												
											</select>
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td width="15%">
											

										</td>
											
											
											
										
										<td>
											
											
											
										</td>
										
										
									
									
									
							        </tr>
									<!-- inner table row 13  -->
									
									
									
									<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Post Office <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											
											<select name="postOfficePresentStage2" required>
												
												<option value="" selected >-select-</option>
												<option value="postOffice">-postOffice-</option>
												
												
											</select>
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>	
												
												
												
												
										</td>
										
										<td>
										
											
											
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 14  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Contact No. : <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="text" name="contactNoPerson" required >
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td width="15%" >
											

										</td>
											
											
										
										
										<td>
											
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 15  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Email : <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="Email" name="emailNoPerson"  required >
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td width="15%" >
											

										</td>
											
											
										
										
										<td>
											
											
											
										</td>
										
										
									
									
									
							        </tr>
									<!-- inner table row 16  -->
									
									
									
									<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Relationship :<span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<select name="relationshipStage2" required>
												
												<option value="" selected >-select-</option>
												<option value="brother">brother</option>
												
												
											</select>
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>	
											

											<a href="index.php" >
											<button type="button">Previous Page</button>	
											</a>
												
												
										</td>
										
										<td>
										
											
											
											<input type="Submit" name="SubmitOfStage2"  value="Save & Next">
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									
									
									
									
										
										
									
									
									
							        
									
									
							</TABLE>
							
							
						</td>
						
					</tr>
					
				</table>
				

			</form>
	</body>
</html>