<!doctype html>
<html>
<head>
<style>
table, th, td {
    border: 0px solid black;
    border-collapse: collapse;
	
}
p { 
    display: block;
    font-size: 1em;
    margin-top: 0.0em;
    margin-bottom: 0.0em;
    margin-left: 0;
    margin-right: 0;
    
}



</style>
</head>
	<body>
		<?phpsession_start();?>
			<form method="POST" action="stage2.php">
				
				<table width="100%">
					<!-- 1st row -->
					<tr>
						<td width="1%"></td>
						<td>	
							<p style="color:black;font-weight: bold;">Passport Application Stage-1</p></br>
							
							
						
						
						</td>
						
					</tr>
					
					<!-- 2nd row -->
					<tr>
						<td width="1%"></td>
						<td><p style="color:tomato;font-size: 0.7em; margin-bottom: 0.5em;font-weight: bold;"> &nbsp Before filling up the online application form read the guaidlince carefully</p>
							<p style="color:black;font-size: 0.7em;margin-top: 0.2em; margin-bottom: 1.5em;">&nbsp Fields marked with (<span style="color: red;">*</span>)madatory</p>
						</td>
						
							
					</tr>
					
					<!-- 3rd row  -->
					<tr>
						<td></td>
						
						<td >
							<TABLE width="100%">
							<!-- inner table row 1  -->
									<tr>
										<td width="1%"></td>
										<td colspan=5 ; width="50%">
											<p style="color:green;font-size: 0.8em;font-weight: bold;">Passport Information Application</p></br>
										</td>
											
									</tr>
									
									<!-- inner table row 2  -->
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Applying in : <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											<select name="applyingIn" required >
												
												<option value="bangladesh" selected>Bangladesh</option>
												<option value="">Other</option>
												
												
											</select>
										
										
										</td>
										<td width="8%"></td>
										<td>
											<p style="color:black;font-size: 0.8em;">Date of Birth :<span style="color: red;">*&nbsp</span></p>	
											
										</td>
										
										<td>
											<input type="date" name="bday" required>
											
											
										</td>
										
										
									
									
									
							        </tr>
										
									
									
									
									
									<!-- inner table row 3  -->
									<tr>
										<td width="2%"></td>
										
										<td><p style="color:black;font-size: 0.8em;margin-top: 0.3em;">Applycation Type  :  </p></td>
										<td><p style="color:black;font-size: 0.8em;font-weight: bold;margin-top: 0.3em;">New Application </p></td>
										<td></td>
										<td><p style="color:black;font-size: 0.8em;margin-top: 0.3em;">Gender  :  <span style="color: red;">*&nbsp</span></p></td>
										<td>
											<input type="radio" name="gender" value="male" required> Male<br>
											<input type="radio" name="gender" value="female" > Female<br>
											<input type="radio" name="gender" value="other" > Other
										</td>
									</tr>
									
									<!-- inner table row 4  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Passport Type : <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											<select required name="passportType" >
												
												
												<option value="">--Select--</option>
												<option value="normal">Normal</option>
												
												
											</select>
										
										
										</td>
										<td width="8%"></td>
										<td>
											
											<p style="color:black;font-size: 0.8em;">BirthId : <span style="color: red;">*&nbsp</span></p>
											
											
										</td>
										
										<td>
											<input type="text" name="birthId" required>
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									
									<!-- inner table row 5  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Delivery Type : <span style="color: red;">&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="radio" name="gender" value="regular">Reguala<br>
											<input type="radio" name="gender" value="express">Express
										
										
										
										</td>
										
										<td width="10%"></td>
										
										<td style="color:black;font-size: 0.8em;margin-top:0.5em;margin-bottom:0.5em;">
											
											<p>NationalId : <span style="color: red;">&nbsp</span></p><br>
											 Tax ID No.:
											
										</td>
										
										<td>
											<input type="text" name="nationalId"/>
											<input type:"text" name="TaxIDNo">
											
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 6  -->
									<tr>
										
										<td width="2%"></td>
										<td colspan=3 ; width="60%">
										<p style="color:green;font-size: 0.8em;font-weight: bold;margin-top: 0.0em;">Personal Information</p></br>
										</td>
										
										<td>
											<p style="color:black;font-size: 0.8em;">Height: <span style="color: red;">*&nbsp</span></p>
										</td>
											

										<td>
											<input type="text" name="cm"  size="3" required >cm<span style="color: red;">&nbsp</span><input type="text" name="inch"  size="3" required > inch
										
										</td>	
										
										
									</tr>
									
									
									
									<!-- inner table row 7  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Name<br> of Applicant: <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="text" name="nameOfApplicant" required >
											
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>
											<p style="color:black;font-size: 0.8em;">Religion: <span style="color: red;">*&nbsp</span></p>

										</td>
											
											
										
										
										<td>
											<select name="religion" required>
												
												<option value="" >-Select-</option>
												<option value="islam">Islam</option>
												
												
											</select>
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 8  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">First Part (Given<br> Name): <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="text" name="nameOfApplicantFirstPart" required >
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>
											<p style="color:black;font-size: 0.8em;">Email: <span style="color: red;">*&nbsp</span></p>

										</td>
											
											
										
										
										<td>
											<input type="Email" name="applicantEmail" required>
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									
									<!-- inner table row 9  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
											<p style="color:black;font-size: 0.8em;">Second Part <br> (Surname): <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
										    <input type="text" name="nameOfApplicantSecondPart" required>
										
										
										
										</td>
										
										<td width="10%">
										
										
										</td>
										
										
										
										<td colspan=2>
											
											
											<p style="color:green;font-size: 0.8em;font-weight: bold;margin-top: 0.0em;">Citizenship Information	</p></br>

										</td>
										
										
										
										
										
										
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 10  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										
										
										<td colspan=2 style="color:black;font-size: 0.8em; ">	
										
											Guardian<input type="checkbox" name="Guardianinfo" value="Guardian"><i style="color:red">"Tick"</i>only if the Applicant is legally adapted
											
											
										</td>
										
										
										
										<td width="10%">
										
										
										</td>
										
										
										
										<td>
											<p style="color:black;font-size: 0.8em;">Nationality: <span style="color: red;">*&nbsp</span></p>

										</td>
											
											
										
										
										<td>
											<select name="nationality" required>
												<option value="">-select-</option>
												<option value="bangladesh" selected >Bangladesh</option>
												<option value="bangladesh">Bangladesh</option>
												
												
											</select>
											
											
										</td>
										
										
										
										
										
										
										
										
									
									
									
							        </tr>
									
									
									<!-- inner table row 11  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Father's name: <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="text" name="nameOfFather" required >
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td width="15%">
											<p style="color:black;font-size: 0.8em;">Citizenship status<span style="color: red;">*&nbsp</span></p>

										</td>
											
											
										
										
										<td>
											<select name="birthStatus" required>
												
												
												<option value="birthStatus1" selected >Birth</option>
												<option value="birthStatus1">Other</option>
												<option value="">None</option>
												
												
											</select>
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									
									<!-- inner table row 12  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Father's <br>Nationality :<span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<select name="fatherNationality" required>
												
												<option value="bangladesh" selected >Bangladesh</option>
												<option value="other">Other</option>
												
												
											</select>
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Dual Citizenship : <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="radio" name="dual" required>Yes<br>
											<input type="radio" name="dual" >No
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									<!-- inner table row 13  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Father's <br>Occupation :<span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<select name="fatherOccupation" required>
												
												<option value="" selected >-select-</option>
												<option value="job">-Job-</option>
												<option value="none">-none-</option>
												
												
											</select>
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td colspan=2>	
												
												
												<p style="color:green;font-size: 0.9em;font-weight: bold;">  Present Address </p></br>
												
										</td>
										
										<td>
										
											
											
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									
									
									<!-- inner table row 14  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Mother's name: <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="text" name="nameOfMother" required>
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td width="15%">
											<p style="color:black;font-size: 0.8em;">Village/House: <span style="color: red;">&nbsp</span></p>

										</td>
											
											
										
										
										<td>
											<input type="text" name="villageHousepersent"  >
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									
									<!-- inner table row 15  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Mother's <br>Nationality :<span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<select name="MotherNationality" required>
												<option value="">-select-</option>
												<option value="bangladesh" selected >Bangladesh</option>
												<option value="other">Other</option>
												
												
											</select>
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Road/Block/Section <span style="color: red;">&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="Text" name="roadPresent" >
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									<!-- inner table row 16  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Mother's <br>Occupation :<span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<select name="motherOccupation" required>
												
												<option value="" selected >-select-</option>
												<option value="oc1">-oc1-</option>
												<option value="none">-none-</option>
												
												
											</select>
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">District :<span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											<select name="districPresent" required>
												
												<option value="" selected >-select-</option>
												<option value="district1">-district-</option>
												
												
											</select>
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									
									
									<!-- inner table row 17  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Spoue's name: <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="text" name="nameOfSpoue"required >
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td width="15%">
											<p style="color:black;font-size: 0.8em;">Police Station: <span style="color: red;">*&nbsp</span></p>

										</td>
											
											
											
										
										<td>
											<select name="policePresent" required>
												
												<option value="" selected >-select-</option>
												<option value="police1">Police1</option>
												
												
											</select>
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									
									<!-- inner table row 18  -->
									
									
									
									<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Spoue's <br>Nationality :<span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<select name="SpoueNationality" required>
												
												<option value="" selected >-select-</option>
												<option value="nationalitySelect1">-nationalitySelect1-</option>
												
												
											</select>
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Post Office <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<select name="postOfficePresent" required>
												
												<option value="" selected >-select-</option>
												<option value="postOffice1">postOffice1</option>
												
												
											</select>
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									<!-- inner table row 19  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Spoue's <br>Occupation :<span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<select name="spoueOccupation" required>
												
												<option value="" selected >-select-</option>
												<option value="job">-job-</option>
												
												
											</select>
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td colspan=2>	
												
												
												<p style="color:green;font-size: 0.9em;font-weight: bold;">  Permanent Address </p></br>
												<input type="checkbox" name="Permanent_Address" value="Per_Add"> Same as above
												
										</td>
										
										<td>
										
											
											
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 20  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Maritual Status :<span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<select name="maritualStatus" required>
												
												<option value="" selected >-select-</option>
												<option value="single">Single</option>
												
												
											</select>
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td width="15%">
											<p style="color:black;font-size: 0.8em;">Village/House: <span style="color: red;">&nbsp</span></p>

										</td>
											
											
										
										
										<td>
											<input type="text" name="villageHouseParmanent"  >
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									
									<!-- inner table row 21  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Applicant's <br>Profession :<span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<select name="applicantProfession" required>
												
												<option value="" selected >-select-</option>
												<option value="job">-job-</option>
												
												
											</select>
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Road/Block/Section <span style="color: red;">&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="Text" name="roadParmanent"  >
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 22  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Country of <br>Birth :<span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<select name="countryBirth" required>
												
												<option value="bangladesh" selected >Bangladesh</option>
												<option value="">Other</option>
												
												
											</select>
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">District :<span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											<select name="districParmanent" required>
												
												<option value="" selected >-select-</option>
												<option value="distric">district</option>
												
												
											</select>
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									<!-- inner table row 23  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">District Birth :<span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<select name="districtBirth" required>
												
												<option value="" selected >-select-</option>
												<option value="distric">distric</option>
												
												
											</select>
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Police Station <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<select name="policeStationParmanent" required>
												
												<option value="" selected >-select-</option>
												<option value="police">police</option>
												
												
											</select>
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									<!-- inner table row 24  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												
												
										</td>
										
										<td>
										
											
											
											
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Post Office <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<select name="postOfficeParmanent" required>
												
												<option value="" selected >-select-</option>
												<option value="postOffice">postOffice</option>
												
												
											</select>
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 25  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												
												
										</td>
										
										<td>
										
											
											
											
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>	
												
												
												
												
										</td>
										
										<td>
										
											
											
											
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									<!-- inner table row 26   -->
									
									
									
									<tr>
										
										
										
										<td width="2%"></td>
										<td>	
												
												
												
												
										</td>
										
										<td>
										
											
											
											
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>	
												
												
												
												
										</td>
										
										<td>
										
											
											<input type="Submit" name="submit" Value="Save & Next">
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									
									
									
										
										
									
									
									
							        
									
									
							</TABLE>
							
							
						</td>
						
					</tr>
					
				</table>
				

			</form>
	</body>
</html>