<!doctype html>
<html>
<head>
<style>
table, th, td {
    border: 0px solid black;
    border-collapse: collapse;
	
}
p { 
    display: block;
    font-size: 1em;
    margin-top: 0.0em;
    margin-bottom: 0.0em;
    margin-left: 0;
    margin-right: 0;
    
}



</style>
</head>
	<body>
	<?phpsession_start();?>
		
			<form method="Post" action="stage4.php">
				
				<table width="100%">
					<!-- 1st row -->
					<tr>
						<td width="1%"></td>
						<td>	
							<p style="color:black;font-weight: bold;">Passport Application Stage-3</p></br>
							
							
						
						
						</td>
						
					</tr>
					
					<!-- 2nd row -->
					<tr>
						<td width="1%"></td>
						<td><p style="color:Green;font-size: 0.7em; margin-bottom: 0.5em;font-weight: bold;"> &nbsp Online application id:000001213</p>
							<p style="color:black;font-size: 0.7em;margin-top: 0.2em; margin-bottom: 1.5em;">&nbsp Fields marked with (<span style="color: red;">*</span>)madatory</p>
						</td>
						
							
					</tr>
					
					<!-- 3rd row  -->
					<tr>
						<td></td>
						
						<td >
							<TABLE width="100%">
							<!-- inner table row 1  -->
									<tr>
										<tr>
										<td width="1%"></td>
										<td colspan=2 ; width="40%">
											<p style="color:green;font-size: 0.8em;font-weight: bold;">Payment Infromation</p></br>
										</td>
										<td width="5%"></td>
										
										<td colspan=2 ; width="50%">
											
										</td>
										
											
									</tr>
									
									<!-- inner table row 2  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">payment Type : <span style="color: red;">&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="radio" name="paymentType">Online<br>
											<input type="radio" name="paymentType">Non-Online
										
										
										
										</td>
										<td width="5%"></td>
										
											
										<td width="15%">
											

										</td>
											
											
										
										
										<td>
											
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 3  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td height="10">	
												
												
												
												
										</td>
										
										<td>
										
											
											
											
										
										
										
										</td>
										<td width="5%"></td>
										
											
										<td width="15%">
											

										</td>
											
											
										
										
										<td>
											
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									
									<!-- inner table row 3  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td >	
												
												
												<input type="checkbox" name="Permanent_Address" value="Per_Add"> <i> Skip Payment</i>
												
										</td>
										
										<td>
										
											
											
											
										
										
										
										</td>
										<td width="5%"></td>
										
											
										<td width="15%">
										

										</td>
											
											
										
										
										<td>
											
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 4  -->
									<tr>
										<tr>
										<td width="1%"></td>
										<td height="10">
											
										
										
										
										
										</td>
										<td width="8%"></td>
										
										<td>
											
										</td>
										<td>
											
										</td>
										
											
									</tr>
									
									<!-- inner table row 5  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td width="25%" height="30">	
												
												
												<p style="color:black;font-size: 0.8em;">Amount : <span style="color: red;">*&nbsp </span></p>
												
										</td>
										
										<td width="35%">
										
											
											
											<select  name="amountPay" required >
												
												<option value=""  selected >-Select-</option>
												<option value="pay">BDT</option>
												
												<p style="color:black;font-size: 0.8em;"> <span style="color: red;">&nbsp &nbsp </span></p>
												<input type="Text" name="amount" size="5" required>
												
												
												
											
												
												
											</select>
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td width="15%" >
											

										</td>
											
											
										
										
										<td>
											
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td height="30">	
												
												
												<p style="color:black;font-size: 0.8em;">Date of payment: <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											<input type="date" name="datePayment" required >
											
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td width="15%">
											

										</td>
											
											
										
										
										<td>
											
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 10  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td height="30">	
												
												
												<p style="color:black;font-size: 0.8em;">Receipt No. <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td>
										
											
											
											<input type="Text" name="receipt" required >
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>	
												
												
												
												
										</td>
										
										<td>
										
											
											
											
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									
									
									<!-- inner table row 11  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Name Of Bank :<span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td height="30">
										
											
											
											<select name="bankname" required>
												
												<option value="">-select-</option>
												<option value="bank">Bank</option>
												
												
											</select>
										
										
										</td>
										<td width="10%"></td>
										
											
										<td>	
												
												
												
												
										</td>
										
										<td>
										
											
											
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 12  -->
									
									
									
									<tr>
										
										
										<td width="2%"></td>
										<td>	
												
												
												<p style="color:black;font-size: 0.8em;">Name of Branch <span style="color: red;">*&nbsp</span></p>
												
										</td>
										
										<td height="30">
										
											
											
											<select name="branchName" required>
												
												<option value=""  >-select-</option>
												<option value="branch">branch</option>
												<option value="branch">branch</option>
												<option value="branch">branch</option>
												
												
											</select>
										
										
										
										</td>
										<td width="10%"></td>
										
											
										<td width="15%">
											

										</td>
											
											
											
										
										<td>
											
											
											
										</td>
										
										
									
									
									
							        </tr>
									
									<!-- inner table row 16  -->
									
									
									
									<td width="2%"></td>
										<td>	
												
												
												
										</td>
										
										<td>
										
											
											
											
										
										
										</td>
										<td width="10%"></td>
										
											
										<td height="30">	
											

											<a href="stage2.php" >
											<button type="button">Previous Page</button>	
											</a>
												
												
										</td>
										
										<td>
										
											
											
											<input type="Submit" name="submitOfStage3  value="Save & Next">
											
										
										
										
										</td>
										
										
									
									
									
							        </tr>
									
									
									
									
										
										
									
									
									
							        
									
									
							</TABLE>
							
							
						</td>
						
					</tr>
					
				</table>
				

			</form>
	</body>
</html>