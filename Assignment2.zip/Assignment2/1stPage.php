<html>
	<head>
		<title>Assignment 2</title>
	</head>
	<body>
		</br>
		
		<table border= "1 px" align="center">
			<tr>
				
				<td width="10%">
				
				
				</td>
				<td style="color:black;font-weight: bold;text-align:center;">
					Character Frequency Counter
					
				</td>
				
				<td width="10%">
				</td>
			
			</tr>
			<tr >
				<td width="10%" height="25">
				
				
				</td>
				<td style="color:black;font-weight: bold;text-align:center;">
					
					
				</td>
				
				<td width="10%">
				</td>
			</tr>
			<tr >
				<td width="10%" height="50">
				
				
				</td>
				<td style="color:black;text-align:center;">
					Insert your string into the following text area to get the count per character
					
				</td>
				
				<td width="10%">
				</td>
			</tr>
			
			<tr >
				<td width="10%" height="50">
				
				
				</td>
				<td style="color:black;text-align:center;">
					<form action="2ndPage.php" name="frequencyCounter" method="post"  align="center" >
						<input type="text" name="v1" size="35">
						</br>	
						<input type="submit" value="submit">
					</form>
					
				</td>
				
				<td width="10%">
				</td>
			</tr>
			
			
		</table>
		
		
	</body>
</html>