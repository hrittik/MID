<html>

    <table border="1 px" align="center">
		<tr>
		<td colspan=3 height="50">
		
		<p style="color:black;font-weight: bold;text-align:center">Character Frequency Counter</p>
		       
		</td>
		
		</tr>
		<tr>
		<body>
			<td width="40" height="50">
			</td>
			
			<td>
			
			<?php
				$str1=$_POST['v1'];
	
				$str2=count_chars($str1,1);
				echo "-";
				foreach($str2 as $x1=>$x2)
				{
					
					echo chr($x1)."  ------------------------------------------------- ".$x2;
					echo "<br>";
	    
		
				}
				
				
				
			
			
	
	
	
			?>
			</td>
			<td width="40">
			</td>
		</tr>
		<tr>
		<td colspan=3 height="50">
		
		<p style="color:black;font-weight: bold;text-align:center">Word Counter</p>
		       
		</td>
		
		</tr>
			
		<tr>
			<td>
			</td>
			<td align="center">
					
					<?php
					echo "<br>";
					echo "<br>";
					$str1=$_POST['v1'];
					
					
					

					foreach(array_count_values(str_word_count($str1,1)) as $x1=>$x2)
				{
					
					echo $x1."  ---------------------- ".$x2;
					echo "<br>";
		
				}
				
				
				
					?>
			
			</td>
			<td>
			</td>
		</tr>
		
		
		
		<tr>
			<td>
			</td>
			<td align="center">
			
			<button><a href="1stPage.php"></br>Again</button>
			</td>
			<td>
			</td>
		
		</tr>
	</table>		
	</body>
</html>